package streams

// MakeStreams ...
func MakeStreams() {
	//concurrent stream access over multiple streams test
}
