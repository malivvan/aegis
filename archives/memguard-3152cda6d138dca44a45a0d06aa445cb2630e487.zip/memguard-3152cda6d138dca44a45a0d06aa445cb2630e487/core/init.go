package core

import (
	"github.com/awnumar/memcall"
)

func init() {
	memcall.DisableCoreDumps()
}
