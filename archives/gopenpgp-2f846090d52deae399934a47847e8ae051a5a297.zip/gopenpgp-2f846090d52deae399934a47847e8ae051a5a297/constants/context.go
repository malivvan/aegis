package constants

const SignatureContextName = "context@proton.ch"
