memcall
-------

[![Cirrus CI](https://api.cirrus-ci.com/github/awnumar/memcall.svg)](https://cirrus-ci.com/github/awnumar/memcall)
[![GoDoc](https://godoc.org/github.com/awnumar/memcall?status.svg)](https://godoc.org/github.com/awnumar/memcall)
[![Go Report Card](https://goreportcard.com/badge/github.com/awnumar/memcall)](https://goreportcard.com/report/github.com/awnumar/memcall)

This package provides a cross-platform wrapper over some common memory-related system calls.

Please report any issues that you experience.
